﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CorpNewsNotification.Models
{
    public class BroadcastNews
    {
        public string broadcastDate { get; set; }
    }
}
