﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Data.SqlClient;

namespace CorpNewsNotification.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class GetBroadcastDateController : ControllerBase
    {
        public string publishDate;
        // GET: api/GetBroadcastDate
        [HttpGet]
        public IEnumerable<string> Get()
        {
            return new string[] { "Try ", "https://corpnewsnotification.azurewebsites.net/api/GetBroadcastDate/yyyy-mm-dd" };
        }

        // GET: api/GetBroadcastDate/5
        [HttpGet("{bDate}", Name = "Get")]
        //  public string Get(int id)
        public string Get(string bDate)
        {
            string resultStr = "";
            string statusStr = "";

            publishDate = bDate;
            // Transform the date value format to yyyy-mm-dd, if needed
            if (publishDate.Length != 10){
                DateTime dt = Convert.ToDateTime(publishDate);     // DateTime now = DateTime.Now; 

                publishDate = dt.Year.ToString() + "-" + ("0" + dt.Month).Substring(0,2) + "-" + ("0" + dt.Day).Substring(0,2);
            }            
           
            // SQL connection
            string connectionString = "";
            SqlConnection connection;
            SqlCommand command;
            string sql = "";
            SqlDataReader dataReader;
            connectionString = "Data Source=tcp:bulut1.database.windows.net,1433;Initial Catalog=NewsNotif;User ID=Username;Password=Password; MultipleActiveResultSets = False; Encrypt = True; TrustServerCertificate = False; Connection Timeout = 30;";
            // SQL query
            sql = "SELECT Emp.id as [Employee Id], Emp.name as [Employee Name], NH.title as [News Title], NH.abstract as [News Abstract], NH.language as [News Language], convert(nvarchar(30), NH.publicationdate, 23) as [News Publication Date], NH.author as [News Author] FROM NewsHeadlines NH with(nolock)  inner join Employees Emp with(nolock) on(Emp.language = NH.language) and(Emp.author = NH.author)where convert(nvarchar(30), NH.publicationdate, 23) = '" + publishDate + "'" +
                " union SELECT Emp.id as [Employee Id], Emp.name as [Employee Name], NH.title as [News Title], NH.abstract as [News Abstract], NH.language as [News Language], convert(nvarchar(30), NH.publicationdate, 23) as [News Publication Date], NH.author as [News Author] FROM NewsHeadlines NH with(nolock) " +
                " inner join Employees Emp with(nolock) on(Emp.language = NH.language) and(NH.title like '%' + Emp.Keyword + '%' or NH.Abstract like '%' + Emp.Keyword + '%') " +
                " where convert(nvarchar(30), NH.publicationdate, 23) = '" + publishDate + "'" +
                " group by Emp.id, Emp.name, NH.title, NH.abstract, NH.language, NH.publicationdate, NH.author";

            connection = new SqlConnection(connectionString);
            try
            {
                connection.Open();
                command = new SqlCommand(sql, connection);
                dataReader = command.ExecuteReader();
                resultStr = dataReader.GetName(0) + ", " + dataReader.GetName(1) + ", " + dataReader.GetName(2) + ", " + dataReader.GetName(3) + ", " + dataReader.GetName(4) +", " + dataReader.GetName(5) + ", " + dataReader.GetName(6) + "\n";
                while (dataReader.Read())
                {
                    resultStr = resultStr + dataReader.GetValue(0) + ", " + dataReader.GetValue(1) + ", " + dataReader.GetValue(2) + ", " + dataReader.GetValue(3) + ", " + dataReader.GetValue(4) + ", " + dataReader.GetValue(5) + ", " + dataReader.GetValue(6) + "\n";
                }
                dataReader.Close();
                command.Dispose();
                connection.Close();
            }
            catch (Exception ex)
            {
                statusStr = "Can not open SQL connection ! ";
            }
            return statusStr + resultStr;
        }

        // POST: api/GetBroadcastDate
        [HttpPost]
        public void Post([FromBody] string value)
        {
        }

        // PUT: api/GetBroadcastDate/5
        [HttpPut("{id}")]
        public void Put(int id, [FromBody] string value)
        {
        }

        // DELETE: api/ApiWithActions/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
        }
    }
}
